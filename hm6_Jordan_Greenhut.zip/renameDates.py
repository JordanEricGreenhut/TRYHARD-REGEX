"""Homework 6, Exercise 2
Jordan Greenhut
10/9/2019
The program renames files with American-style dates
to European-style dates. The program uses Regex to
identify different parts of the date. The program
assigns these parts to a variable. Then it changes
the date to European-Style and it renames the file
accordingly
"""
import os, shutil, re
americanRegex = re.compile(r'''^(.*?)   # Text before date
     ((0|1)?\d)-                          # month
     ((0|1|2|3)?\d)                       # day
     ((19|20)\d\d)                        # four digit year
     (.*?)$
     ''',re.VERBOSE)
#initialize count to zero outside the loop
count = 0
for dirName, subdirList, fileList in os.walk('.'):
    for americanFile in fileList:                       # Iterating all files in current directory
        match = americanRegex.search(americanFile)        #matching the regular expression
        if match != None:   #if there is no American-style dates, don't run if loop
            count+=1
            #assign the sections of the date to a variable
            beforeDate = match.group(1)
            monthPart  = match.group(2)
            dayPart    = match.group(4)
            yearPart   = match.group(6)
            afterPart  = match.group(8)
            #reconstruct the date but as European-Style
            europeanFile = beforeDate + dayPart + '-' + monthPart + yearPart + afterPart
            absolute = os.path.abspath('.')
            #define path
            pathamericanFile = os.path.join(absolute,dirName)
            #define file
            americanFile = os.path.join(pathamericanFile,americanFile)
            #define path
            path = os.path.join(absolute, dirName)
            #define file
            europeanFile = os.path.join(path,europeanFile)
            print(europeanFile)
            shutil.move(americanFile,europeanFile)    #Renaming file
#tell the user how many files have been renamed
print (str(count) + " files renamed.")