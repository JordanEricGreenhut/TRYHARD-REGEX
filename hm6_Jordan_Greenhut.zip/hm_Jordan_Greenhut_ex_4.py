""""
Homework 6, Exercise 1
Jordan Greenhut
10/9/2019
This program "Deleting Unneeded Files" searches
the computer for the largest files. Once it has
found the largest files it prints the path to
these files on the screen so they can potentially
be deleted"""
import os, shutil, sys

if __name__ == "__main__":
    try:
        import __builtin__
        input = getattr(__builtin__, 'raw_input')
    except (ImportError, AttributeError):
        pass                                            #To use input method in Python2

    rootDir = input("Enter folder to copy from\n")      #Inputing the Folder to copy files from
    copyTo = input("Enter folder to copy to\n")            #Inputing the folder to copy files to
    extensionToCopy = input("Enter file extension to copy \n")  #Inputting the file extension to copy
    if extensionToCopy[0] != '.' :
        extensionToCopy = '.' + extensionToCopy    
    count = 0            
    for dirName, subdirList, fileList in os.walk(rootDir):
        for fname in fileList:                            #Iterating all the files in current directory 
            if extensionToCopy == os.path.splitext(fname)[1]:  #Checking if file extension matches with required
                count+=1
                if not os.path.exists('./' +copyTo + '/'):        #Creating folder if it don't already exist
                    os.mkdir('./' +copyTo + '/')
                fullPath = dirName + '/' + fname
                print (os.path.abspath(fullPath))
                shutil.copy(fullPath, './' +copyTo + '/')       #Copying selected files
    print (str(count) + " files copied") 
