"""
Homework 6, Exercise 1
Jordan Greenhut
10/9/2019
This program is the Multipclipboard.
The program allows the user to keep track of
multiple pieces of text.  The program saves
each peice of text under a keyword. The program
uses the lower() function to avoid checking both upper
and lower cases. The program can save and delete depending on
the user's discretion
"""
import sys, shelve, pyperclip

if __name__ == '__main__':
    #initialize multiclipboard
    multiClipBoard = shelve.open('mcb')         
    #if statement to check the length of terminal input
    if len(sys.argv)==3:
         #if the terminal says save, then save to mcb
        if sys.argv[1].lower() == 'save':
            multiClipBoard[sys.argv[2]] = pyperclip.paste()
            print ('Text copied to MCB.')
        #otherwise delete
        elif sys.argv[1].lower() == 'delete':
            if sys.argv[2].lower() == 'all':
            #if delete all then delete the whole multiclipboard
                multiClipBoard.clear()
                print ('Deleted all saved clipboards.')
            #otherwise just delete that individual entered input
            elif sys.argv[2] in multiClipBoard:
                del multiClipBoard[sys.argv[2]]
                print (sys.argv[2] + " clipboard deleted.")
    #if the input to terminal has just length 2
    elif len(sys.argv)==2:
        #bring it to lowercase for evaluation so don't have to do both upper and lower
        if sys.argv[1].lower() == 'list':
            for val in multiClipBoard.keys():
                print (val)
        #if list is not entered then do this
        elif sys.argv[1] in multiClipBoard:
            pyperclip.copy(multiClipBoard[sys.argv[1]])
            print (sys.argv[1] + " copied to your original clipboard.")
    #close the application
    multiClipBoard.close()