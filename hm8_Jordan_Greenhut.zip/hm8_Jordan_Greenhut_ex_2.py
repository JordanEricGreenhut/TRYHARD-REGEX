'''
Homework 8, Exercise 2
Jordan Greenhut
10/27/2019
This program is called the "Brute-Force PDF Password Breaker"
The program try every word in a dictionary to encrypt a pdf
document. When the password is found, the pdf doc will be
saved to another file. The loop breaks when the password is
found.
'''
from PyPDF2 import PdfFileReader, PdfFileWriter
import time
def getDictionaryWords(filename):
    f=open(filename, "r")
    contents = []
    if f.mode == 'r':
        contents =f.read()
    words = contents.split('\n')
    return words

def decryptPdf(filename):
    output_path = filename[:len(filename)-4] + "_out.pdf"
    allPasswords = getDictionaryWords("dictionary.txt")
    flag = False
    with open(filename, 'rb') as input_file, \
    open(output_path, 'wb') as output_file:
        reader = PdfFileReader(input_file)
        startTime = int(round(time.time() * 1000))
        for password in allPasswords:
            if reader.decrypt(password) > 0 :
                writer = PdfFileWriter()
                for i in range(reader.getNumPages()):
                    writer.addPage(reader.getPage(i))
                writer.write(output_file)
                flag = True
                endTime = int(round(time.time() * 1000))
                print ("Password is " + password)
                print ("Time taken to decrypt the file is" + str((endTime - startTime)/1000) + "seconds . That's why you should not use single words for your passwords!")
                break
            elif reader.decrypt(password.lower()) > 0:
                writer = PdfFileWriter()
                for i in range(reader.getNumPages()):
                    writer.addPage(reader.getPage(i))
                writer.write(output_file)
                flag = True
                endTime = int(round(time.time() * 1000))
                print ("Password is " + password.lower())
                print ("Time taken to decrypt the file is" + str((endTime - startTime)/1000) + "seconds . That's why you should not use single words for your passwords!")
                break
    if flag is False:
        print ("Password not found")
if __name__ == '__main__':
    decryptPdf("encrypted.pdf")
