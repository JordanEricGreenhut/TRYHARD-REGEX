'''
Homework 8, Exercise 1
Jordan Greenhut
10/27/2019
This program is called the spreadsheet cell inverter.
The program inverts the cells in the excel document provided by
the instructor. The program inverts row 5, column 3 with row 3
column 5. 
'''
from openpyxl import Workbook
import openpyxl
filename = 'Book2.xlsx'

# open worksheet using openpyxl
xlsx = openpyxl.load_workbook(filename)
sheet = xlsx.active
data = sheet.rows
row, maxi = 0, 0

# find max of row, col
for r in data:
  l = list(r)
  row += 1
  maxi = max(row, len(l))


# resize worksheet to square matrix so that swapping elements become easy
for row in range(1, maxi+1):
  for col in range(1, maxi+1):
    sheet.cell(row = row, column = col)


# Reload worksheet to the variable data
sheet = xlsx.active
data = sheet.rows
row = 0
for r in data:
  l = list(r)
  # swapping of elements
  for col in range(row+1, len(l)):
    temp1 = sheet.cell(row = row+1, column = col+1).value
    temp2 = sheet.cell(row = col+1, column = row+1).value
    if temp1 is None:
      temp1 = ""
    if temp2 is None:
      temp2 = ""
    sheet.cell(row = row+1, column = col+1, value = temp2)
    sheet.cell(row = col+1, column = row+1, value = temp1)
  row += 1
xlsx.save(filename)