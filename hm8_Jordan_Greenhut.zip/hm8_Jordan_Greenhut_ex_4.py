'''
Homework 8, Exercise 4
Jordan Greenhut
10/27/2019
This program is called the "Fetching Current Weather Data" program.
The program downloads JSON data from a city from OpenWeatherMap.org
Next, the program convers the data to a python data structure.
Lastly, the program prints the weather for today and the next two days.
'''
import requests
from _datetime import datetime
import pprint
import json

# Fetch data from api
def fetch(city):
	response = requests.get("https://api.openweathermap.org/data/2.5/forecast?q={0}&appid=66ebf8d448793f698a05413d90c21251".format(city))
	return json.loads(response.text)


city = input("Enter city and country code, eg. london,us\n")
data = fetch(city)
weather = {}

# filter the data recieved from api
for instance in data['list']:
	date, time = instance['dt_txt'].split()
	if date not in weather:
		weather[date] = instance['weather'][0]['main']

# results of today, tomorrow, and day after tomorrow
results = sorted(weather.items())[:3]
print(results)