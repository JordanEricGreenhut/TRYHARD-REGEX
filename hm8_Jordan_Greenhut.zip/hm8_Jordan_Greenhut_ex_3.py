'''
Homework 8, Exercise 3 (first part)
Jordan Greenhut
10/27/2019
This program is called the "Census population data" program.
The script analyzes census data to calculate statistics.
The script uses the openxyl module, calculates the number of census
tracts and stores it in a text file, uses pretty print to format the data.
Part 2 accesses the data structure and shows that it works for any country.
'''
from openpyxl import Workbook
import openpyxl
filename = 'censuspopdata.xlsx'
import pprint

# open worksheet using openpyxl
xlsx = openpyxl.load_workbook(filename)
sheet = xlsx.active
data = sheet.rows
row, maxi = 0, 0

ds = {}
# Write file in a dictionary of the format :
# Key   : [value1, value1] which implies
# state : [population, count of census track]
for r in data:
    if row == 0:
        row += 1
        continue
    l = list(r)
    try:
        ds[l[2].value][0] += l[3].value
        ds[l[2].value][1] += 1
    except:
        ds[l[2].value] = [l[3].value,1]
# the data structure will be written to ds_file.py in the current directory
with open("ds_file.py", "w") as fout:
    fout.write("dic = " + pprint.pformat(ds))