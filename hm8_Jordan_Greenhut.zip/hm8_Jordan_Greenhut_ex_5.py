'''
Homework 8, Exercise 5
Jordan Greenhut
10/27/2019
This program is called the "FExcel-to-CSV Converter" program.
The program reads all excel files in the directory and converts
them to CSV format. The filenames must have the following
format: <excel filename>_<sheet . The program involves a few nested
for loops.
'''
import os
import openpyxl

# open the directory
for file in os.listdir('.'):
    # skip file is not excelsheet
    if not file.endswith(".xlsx"):
        continue
    filename, extension = (os.fsdecode(file)).split('.')
    wb = openpyxl.load_workbook(file)
    for sheetName in wb.get_sheet_names():
        sheet = wb.get_sheet_by_name(sheetName)
        # create csvFile with given nomenclature
        csvFile = open(filename + "_" + sheetName + ".csv", "w+")
        data = sheet.rows
        cnt = 0
        # write to csv using csvWriter and leaving the first row
        for row in data:
            if cnt == 0:
                cnt += 1
                continue
            l = list(row)
            for i in range(len(l)):
                if i == len(l) - 1:
                    csvFile.write(str(l[i].value))
                else:
                    csvFile.write(str(l[i].value) + ',')
            csvFile.write('\n')
        csvFile.close()