'''
Homework 8, Exercise 3 (first part)
Jordan Greenhut
10/27/2019
This program is called the "Census population data" program.
The script analyzes census data to calculate statistics.
The script uses the openxyl module, calculates the number of census
tracts and stores it in a text file, uses pretty print to format the data.
Part 2 accesses the data structure and shows that it works for any country.
'''
from ds_file import dic
# from the ds_file.py, read the data structure and print both the attributes
city = input()
try:
    print(dic[city])
except:
    dic[city] = [0, 0]
    print(dic[city])