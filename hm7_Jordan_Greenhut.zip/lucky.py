"""Homework 7, Exercise 1
Jordan Greenhut
10/20/2019
This program opens urls of google search of input query in new browser tabs.
The program will pull a maximum of 5 links.
"""
import requests, webbrowser, sys
from bs4 import BeautifulSoup

def filterHTTP(link):
	if link == None or '.google.' in link: 					#ignoring the url if it's None or is a google url
		return False
	elif 'http' in link: 									#the url must contain http in it
		return True
	return False


def getURLs(html):
	soup = BeautifulSoup(html, 'html.parser') 				#parsing html using BeautifulSoup
	allATags = soup.select('a[href]')						#selecting all <a> tags with href attribute
	allLinks = []
	for link in soup.find_all('a'):
	    allLinks.append(link.get('href')) 					#adding all links to a list
	useFulLinks = filter(filterHTTP, allLinks) 				#filtering useless urls
	return (list(useFulLinks))								#returning only useful urls


def googleSearch(query):
    with requests.session() as c:
        url = 'https://www.google.com/search?q=' + query     	#preparing the url to request
        userAgent = "Mozilla/5.0 (X11; CrOS i686 2268.111.0) AppleWebKit/536.11(KHTML, like Gecko) Chrome/20.0.1132.57 Safari/536.11"
        headers = {'User-Agent': userAgent}
        res = requests.get(url, headers=headers) 			#requesting the url

        links = getURLs(res.text)           				#extracting all useful urls from the html recieved
        length = (min(5, len(links)))
        for x in links[:length]:							#opening at max 5 urls in new tab
        	webbrowser.open(x)

if __name__ == '__main__':
	if len(sys.argv) <=1:
		print ("Enter query to search") 			#if no argument is passed
	else:
		query = ""
		for i in sys.argv[1:]:
			query = query + " " + i  				#concatenating all words passed as argument to make one query

		query = query[1:]							#removing the first extra space
		googleSearch(query)