"""Homework 7, Exercise 2
Jordan Greenhut
10/20/2019
This program goes to Imgur, searches for a category of photos,
and then downloads all the resulting images. The program
uses a function to drive the code after intervals of time,
the function to tell the user whether or not to grab an umbrella,
and a function that displays the message promptly when the user wakes
up
"""
from threading import Timer
from datetime import time, datetime, date, timedelta
import pytz
from time import sleep
import requests
from bs4 import BeautifulSoup

# Class that will drive the code after every particular interval of time and in the mean time it will not be in main thread.
class RepeatedTimer(object):
    def __init__(self, interval, function, *args, **kwargs):
        self._timer     = None
        self.interval   = interval
        self.function   = function
        self.args       = args
        self.kwargs     = kwargs
        self.is_running = False
        self.start()

    def _run(self):
        self.is_running = False
        self.start()
        self.function(*self.args, **self.kwargs)

    def start(self):
        if not self.is_running:
            self._timer = Timer(self.interval, self._run)
            self._timer.start()
            self.is_running = True

    def stop(self):
        self._timer.cancel()
        self.is_running = False
rt = None 


# Function to scrape the climate conditions of New York and return the results
def hello():
    response = requests.get("https://forecast.weather.gov/MapClick.php?lat=40.71455000000003&lon=-74.00713999999994")
    soup = BeautifulSoup(response.text, 'html.parser')
    string = soup.find(class_="short-desc")
    if "rain" in string or "cloud" in string:
        print("It could rain. Pack an umbrella today.")
    elif "snow" in string or "cold" in string:
        print("It's cold outside. Pack an extra jacket today.")
    else:
        print("Good to go outside.")

# Default timezone is settle to New York.
tz = pytz.timezone('America/New_York')
today = datetime.now(tz).date()

print("starting...")

# Assumption is user wakes up at 7 o'clock every day. So this will start the job at the Nearest 7 o'clock and the keep on repeating everyday.
time_left = 0
if datetime.combine(today, time(hour=7)) < datetime.combine(today, datetime.now(tz).time()):
    time_left = datetime.combine(today + timedelta(days=1), time(hour=7)) - datetime.combine(today, datetime.now(tz).time())
else:
    time_left = datetime.combine(today, time(hour=7)) - datetime.combine(today, datetime.now(tz).time())

sleep(time_left.total_seconds()//1)
# Commanding function to run the job after every 24 hours.
rt = RepeatedTimer(86400, hello) 
while True:
    pass

